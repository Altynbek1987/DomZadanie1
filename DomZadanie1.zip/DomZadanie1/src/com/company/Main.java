package com.company;

public class Main {

    public static void main(String[] args) {
        final String NAME = "Привет ";// констант всегда пишется в большой буквой
        System.out.println("Это констант "+ NAME);
        String secondName = "Мир";
        String ata = NAME + secondName;// конкатинация
        System.out.println(ata);
    }
}
